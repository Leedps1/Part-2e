package com.mycompany.part2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 1);
        assertEquals("Message ready to send.", msg.checkMessageLength());
        System.out.println("Message length success - PASSED");
    }

    @Test
    public void testMessageLengthFailure() {
        String longMsg = "A".repeat(300); // 300 chars
        Message msg = new Message("+27718693002", longMsg, 1);
        String result = msg.checkMessageLength();
        assertTrue(result.contains("Message exceeds 250 characters by"));
        assertEquals("Message exceeds 250 characters by 50, please reduce size.", result);
        System.out.println("Message length failure - PASSED");
    }

    @Test
    public void testRecipientSuccess() {
        // Test Data 1 from POE: +27718693002 should pass
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 1);
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
        assertTrue(msg.isRecipientValid());
        System.out.println("Recipient success - PASSED");
    }

    @Test
    public void testRecipientFailure() {
        // Test Data 2 from POE: 08575975889 should fail - no +
        Message msg = new Message("08575975889", "Hi Keegan, did you receive the payment?", 1);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", msg.checkRecipientCell());
        assertFalse(msg.isRecipientValid());
        System.out.println("Recipient failure - PASSED");
    }

    @Test
    public void testMessageHashFormat() {
        // Hash should be 00:0:HITHANKS style
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 1);
        String hash = msg.createMessageHash();
        // Should contain : and be uppercase
        assertTrue(hash.contains(":"));
        assertEquals(hash, hash.toUpperCase());
        assertTrue(hash.endsWith("HITONIGHT") || hash.contains("HI"));
        System.out.println("Hash: " + hash + " - PASSED");
    }

    @Test
    public void testMessageIDLength() {
        Message msg = new Message("+27718693002", "Test", 1);
        assertTrue(msg.checkMessageID());
        assertTrue(msg.getFullDetails().contains("Message ID:"));
        System.out.println("Message ID check - PASSED: " + msg.getFullDetails());
    }

    // POE SPECIFIC TEST DATA
    @Test
    public void testPOE_TestData1_Send() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?", 1);
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
        assertEquals("Message ready to send.", msg.checkMessageLength());
        String result = msg.SentMessage(1);
        assertEquals("Message successfully sent.", result);
        System.out.println("POE Test Data 1 - PASSED");
    }

    @Test
    public void testPOE_TestData2_Discard() {
        Message msg = new Message("08575975889", "Hi Keegan, did you receive the payment?", 1);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", msg.checkRecipientCell());
        String result = msg.SentMessage(2);
        assertEquals("Press 0 to delete the message.", result);
        System.out.println("POE Test Data 2 - PASSED");
    }
}
