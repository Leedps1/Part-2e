package com.mycompany.part2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

// classes
class Message {
    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String message;
    private String messageHash;

    private static List<Message> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;

    public Message(String recipient, String message, int numMessagesSent) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.message = message;
        this.numMessagesSent = numMessagesSent;
        this.messageHash = createMessageHash();
    }
    
    
    public Message(String messageID, int numMessagesSent, String recipient, String message) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
        this.numMessagesSent = numMessagesSent;
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random rand = new Random();
        long num = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(num);
    }

    
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }


    public String checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+") && recipient.length() <= 13 && recipient.length() >= 10) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public boolean isRecipientValid() {
        return recipient != null && recipient.matches("^\\+\\d{9,12}$");
    }


    public String checkMessageLength() {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
    }

    
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2) return "";
        String firstTwo = messageID.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z]", "");
        return (firstTwo + ":" + numMessagesSent + ":" + firstWord + lastWord).toUpperCase();
    }

    
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

   
    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append(m.getFullDetails()).append("\n\n");
        }
        return sb.toString();
    }

    
    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

  
    public void storeMessage() {
        try {
            String filePath = "stored_messages.json";
            String jsonEntry = String.format(
                "{\"messageID\":\"%s\",\"messageHash\":\"%s\",\"recipient\":\"%s\",\"message\":\"%s\",\"numMessagesSent\":%d}",
                messageID, messageHash, recipient, message.replace("\"", "'"), numMessagesSent
            );

            String existing = "";
            if (Files.exists(Paths.get(filePath))) {
                existing = new String(Files.readAllBytes(Paths.get(filePath))).trim();
            }

            FileWriter writer = new FileWriter(filePath);
            if (existing.isEmpty() || existing.equals("[]")) {
                writer.write("[\n" + jsonEntry + "\n]");
            } else {
                // Append inside array
                String trimmed = existing.substring(0, existing.lastIndexOf("]")).trim();
                if (trimmed.endsWith("[")) {
                    writer.write(trimmed + "\n" + jsonEntry + "\n]");
                } else {
                    writer.write(trimmed + ",\n" + jsonEntry + "\n]");
                }
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error storing: " + e.getMessage());
        }
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }

    public String getFullDetails() {
        
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message;
    }
}

// ==================== MAIN APP - CHAT ====================
public class Part2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Login check - users should only be able to send messages if they have logged in successfully
        System.out.println("====== Chat Registration ======");
        System.out.print("Enter Username (must contain _ and <=5 chars): ");
        String username = sc.nextLine();
        System.out.print("Enter Password (8 chars, cap, number, special): ");
        String password = sc.nextLine();
        System.out.print("Enter Cell (+27...): ");
        String cell = sc.nextLine();

        if (!(username.contains("_") && username.length() <= 5)) {
            System.out.println("Username invalid."); return;
        }

        System.out.println("\n=== Login ===");
        System.out.print("Username: "); String u = sc.nextLine();
        System.out.print("Password: "); String p = sc.nextLine();
        if (!u.equals(username) || !p.equals(password)) {
            System.out.println("Username or password incorrect."); return;
        }

        System.out.println("\nWelcome to Chat.");

        System.out.print("How many messages do you wish to enter? ");
        int totalToEnter = Integer.parseInt(sc.nextLine());
        int entered = 0;
        int counter = 0;

        while (entered < totalToEnter) {
            System.out.println("\n--- MENU ---\n1) Send Messages\n2) Show recently sent messages\n3) Quit");
            System.out.print("Choice: "); String opt = sc.nextLine();

            if (opt.equals("1")) {
                counter++;
                System.out.print("Enter Recipient (e.g. +27718693002): ");
                String recipient = sc.nextLine();
                System.out.print("Enter Message (max 250 chars): ");
                String text = sc.nextLine();

                if (text.length() > 250) {
                    System.out.println("Please enter a message of less than 250 characters.");
                    counter--; continue;
                } else {
                    System.out.println("Message sent");
                }

                Message msg = new Message(recipient, text, counter);

                if (!msg.checkMessageID()) { System.out.println("Message ID >10 chars"); counter--; continue; }

                System.out.println(msg.checkRecipientCell());
                if (!msg.isRecipientValid()) { counter--; continue; }

                System.out.println("Message Hash: " + msg.getMessageHash());

                System.out.println("What to do?\n1) Send Message\n2) Disregard Message\n3) Store Message to send later");
                System.out.print("Choice: "); int choice = Integer.parseInt(sc.nextLine());

                String result = msg.SentMessage(choice);
                System.out.println(result);

                if (choice == 2) {
                    System.out.print("Press 0 to delete: "); String del = sc.nextLine();
                    if (del.equals("0")) System.out.println("Message deleted.");
                    counter--; continue;
                }

                if (choice == 1) {
                    System.out.println("\n--- Full Details ---");
                    System.out.println(msg.getFullDetails());
                    entered++;
                } else if (choice == 3) {
                    entered++;
                }

                System.out.println("Total messages sent: " + Message.returnTotalMessagess());

            } else if (opt.equals("2")) {
                System.out.println("Coming Soon.");
            } else if (opt.equals("3")) {
                break;
            }
        }

        System.out.println("\nTotal number of messages sent: " + Message.returnTotalMessagess());
        if (Message.returnTotalMessagess() > 0) {
            System.out.println(Message.printMessages());
        }
        sc.close();
    }
}
